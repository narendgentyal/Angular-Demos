import { AppTitleDirective } from './app-title.directive';

describe('AppTitleDirective', () => {
  it('should create an instance', () => {
    const directive = new AppTitleDirective();
    expect(directive).toBeTruthy();
  });
});
