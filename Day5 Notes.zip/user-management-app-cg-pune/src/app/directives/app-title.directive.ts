import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appTitle]'
})
export class AppTitleDirective {

  // Injecting ElementRef service for accessing Html Elements
  constructor(element: ElementRef) { 
    // onMouseOver and onMouseOut
    // direction -> right, left, up, down
    element.nativeElement.innerHTML = 
    `
      <div class="bg-primary text-white">
        <marquee id="title" direction="right" scrollamount="10"
          onMouseOut="document.getElementById('title').start()"
          onMouseOver="document.getElementById('title').stop()">
            <h1> Welcome to User Management App </h1>
        </marquee>
      </div>
    `;
  }


}
