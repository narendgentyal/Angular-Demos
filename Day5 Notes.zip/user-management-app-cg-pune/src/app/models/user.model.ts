// Creating User Model class
export class User{
    id: number;
    firstName: string;
    lastName: string;
    age: number;
    mobileNumber: string;
    email: string;
    password: string;
}