import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { ListUserComponent } from './components/list-user/list-user.component';



// define routes for your components
// defining array of objects of Routes
const routes: Routes = [
  // Empty Route
  {path:'', component:HomeComponent},
  {path:'home', component:HomeComponent},
  {path:'login', component:LoginComponent},
  {path:'add-user', component:AddUserComponent},
  // we can use localStorage
  // {path:'edit-user', component:EditUserComponent},
  // we can use routeParams
  {path:'edit-user/:id', component:EditUserComponent},

  {path:'list-user', component:ListUserComponent},

  // Default Route
  // {path:'**',component:HomeComponent},
  {path:'**',redirectTo:'/home', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
