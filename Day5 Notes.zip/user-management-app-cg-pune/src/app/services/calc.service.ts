import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalcService {

  constructor() { }

  addition(fn: number, sn: number):number{
    return (fn+sn);
  }

  multiplication(fn: number, sn:number): number{
    return (fn*sn);
  }
}
