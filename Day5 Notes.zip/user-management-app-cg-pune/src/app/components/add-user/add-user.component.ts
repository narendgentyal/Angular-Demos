import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;

  // Injecting all relevant services inside the constructor
  constructor(private formBuilder: FormBuilder,
    private router: Router, private userService: UserService) { }

  // Life Cycle Hook
  ngOnInit() {
    if (localStorage.username != null) {
      this.addForm = this.formBuilder.group({
        firstName: ['', [Validators.required, Validators.pattern("[A-Z][a-z]{2,14}")]],
        lastName: ['', Validators.required],
        age: ['', [Validators.required, Validators.min(20), Validators.max(30)]],
        mobileNumber: ['', [Validators.required, Validators.pattern("[6-9][0-9]{9}")]],
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required]
      });
    }
    else {
      this.router.navigate(['/login']);
    }
  }

  // addUser() function
  addUser() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    // on successful validations, execute below code snippet

    console.log(this.addForm.value);

    this.userService.createNewUser(this.addForm.value).subscribe(data => {
      alert(`${this.addForm.controls.firstName.value} record is added successfully ..!`);
      this.router.navigate(['list-user']);

    }, err => {
      console.log(err.stack);
    })
  }
}
