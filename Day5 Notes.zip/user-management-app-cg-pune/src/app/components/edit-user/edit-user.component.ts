import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;

  currentId: number;
  // Injecting all relevant services inside the constructor
  constructor(private formBuilder: FormBuilder,
    private router: Router, private userService: UserService,
    private route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.currentId = params['id'];
    })
    console.log(this.currentId);
  }

  // Life Cycle Hook
  ngOnInit() {
    if (localStorage.username != null) {
      this.editForm = this.formBuilder.group({
        id: [this.currentId],
        firstName: [{ value: '', disabled: true }, [Validators.required, Validators.pattern("[A-Z][a-z]{2,14}")]],
        lastName: [{ value: '', disabled: true }, Validators.required],
        age: ['', [Validators.required, Validators.min(20), Validators.max(30)]],
        mobileNumber: ['', [Validators.required, Validators.pattern("[6-9][0-9]{9}")]],
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required]
      });

      // pulling data from service by id
      this.userService.getUserById(this.currentId).subscribe(data => {
        console.log(data);
        // binding josn response to form object
        this.editForm.setValue(data);
      },
        err => {
          console.log(err.stack);
        })
    }
    else {
      this.router.navigate(['/login']);
    }
  }

  // logOutUser() function
  logOutUser() {
    if (localStorage.username != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }
  // updateUser() function
  updateUser() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }

    this.userService.updateUserById(this.editForm.getRawValue()).subscribe(data => {
      this.router.navigate(['list-user']);
    },
      err => {
        console.log(err.stack);
      })
  }
}
