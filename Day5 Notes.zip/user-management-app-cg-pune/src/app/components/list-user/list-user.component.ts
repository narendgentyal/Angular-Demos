import { Component, OnInit } from '@angular/core';
import { CalcService } from '../../services/calc.service';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {

  // searchText = "Amit";
  searchText:any;
  
  // to handle list of users
  users: User[];

  // injecting UserService which is using HttpClient service
  constructor(private userService: UserService, private router: Router) { }

  // Life cycle hook
  ngOnInit() {
    if (localStorage.username != null) {
      this.getUsers();
    }
    else {
      this.router.navigate(['/login']);
    }
  }

  getUsers() {
    this.userService.getAllUsers().subscribe(data => {
      // on resolve or on success
      this.users = data;
      console.log(this.users);
    },
      err => {
        // on reject or on error
        console.log(err.stack);
      });
  }
  // logOutUser() function
  logOutUser() {
    if (localStorage.username != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }

  // addUser() function
  addUser() {
    this.router.navigate(['add-user']);
  }

  // editUser(user) function
  editUser(user){
    this.router.navigate(['edit-user',user.id]);
  }


  // deleteUser(user) function
  deleteUser(user: User) {
    let result = confirm("Do you want to delete user?");
    if (result) {
      this.userService.deleteUserById(user.id)
        .subscribe(data => {
          this.users = this.users.filter(u => u.id !== user.id);
        },
          err => {
            console.log(err.stack);
          });

          // alert(user.firstName+" record is deleted ..!");
          alert(`${user.firstName}  record is deleted ..!`);
    }
  }
  // deleteUser(user: User, index) {
  //   let result = confirm("Do you want to delete user?");
  //   if (result) {
  //     this.userService.deleteUserById(user.id).subscribe(data => {
  //       // this.users.splice(index, 1);
  //       this.getUsers();
  //     },
  //       err => {
  //         console.log(err.stack);
  //       });

  //       // alert(user.firstName+" record is deleted ..!");
  //       alert(`${user.firstName}  record is deleted ..!`);
  //   }
  // }



  // UNDERSTANDING CalcService 
  // sum: number;
  // product: number;

  // // Injecting CalcService
  // constructor(private calcService: CalcService) { }

  // ngOnInit() {
  //   this.sum = this.calcService.addition(100,200);
  //   this.product = this.calcService.multiplication(100,200);
  // }



}
