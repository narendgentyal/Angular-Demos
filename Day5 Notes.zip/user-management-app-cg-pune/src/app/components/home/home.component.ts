import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // Implicitely typed, title will be of string type
  title = "welcome to angular 8";
 // NOTE: if you dont initialise any value to variable, Typescript will take undefined type 
  // companyName;

  constructor() { }

  ngOnInit() {
    
  }

}
