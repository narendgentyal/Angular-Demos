import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // creatinf FormGroup object
  loginForm: FormGroup;

  submitted: boolean= false;
  // Constructor Dependency Injection
  // Dependency Injection makes your application loosey typed
  // So that application can be easily maintained

  // FormBuilder to build form elements with defaut values and validations
  // Router service to navigate programmatically from component to other
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  // Life Cycle Hook
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email:['',Validators.required],
      password: ['', Validators.required]
    });
  }

  verifyLogin(){
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }

    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;

    if(username == "admin@gmail.com" && password=="password@123")
    {
      localStorage.username = username;
      sessionStorage.username = username;
      this.router.navigate(['list-user']);
    }
    else{
      this.invalidLogin = true;
    }
  } // end of verifyLogin() function

  invalidLogin:boolean = false;
}



// Javascript object
  // custDetails = {
  //   name:'Mukund',
  //   age: 25,
  //   address: {
  //     city: 'Bangalore',
  //     state:'Karnataka'
  //   }
  // }

  // Array Data
  // months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
