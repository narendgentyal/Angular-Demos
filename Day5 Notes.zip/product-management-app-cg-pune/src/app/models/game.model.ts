export class Game{
    gameId: number;
    gameName: string;
    photo: string;
    gamePrice: number;
}