import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GamesListComponent } from './components/games-list/games-list.component';
import { RegisterComponent } from './components/register/register.component';
import { StructuralDirectiveComponent } from './components/structural-directive/structural-directive.component';
import { AttributeDirectiveComponent } from './components/attribute-directive/attribute-directive.component';
import { LifeCycleComponent } from './components/life-cycle/life-cycle.component';


const routes: Routes = [
  {path:'', component:RegisterComponent},
  {path:'games', component:GamesListComponent},
  {path:'register', component:RegisterComponent},
  {path:'structural', component:StructuralDirectiveComponent},
  {path:'attribute', component:AttributeDirectiveComponent},
  {path:'life-cycle', component:LifeCycleComponent},
  {path:'**', component:GamesListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
