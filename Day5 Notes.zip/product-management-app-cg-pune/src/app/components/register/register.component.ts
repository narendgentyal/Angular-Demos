import { Component, OnInit } from '@angular/core';
import { GameService } from '../../services/game.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  play:boolean= false;

  constructor(private gameService: GameService) { }

  ngOnInit() {
  }

  registerPlayer(player){
    this.play = true;

    // parseInt() and parseFloat() -> parsing from string to number
    let amount: number = parseInt( player.amount);

    if(this.play){
      this.gameService.setBalance(amount);
      this.gameService.deductServiceCharge();
      alert('Your details submitted successfully..!\n Click on Start Playing Link ..!');
    }

  }
}
