import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structural-directive',
  template:`
          <h2>{{title}}</h2>
          <hr/>
          <div [ngSwitch]="day">
            <p *ngSwitchCase="1">You have selected Monday </p>
            <p *ngSwitchCase="2">You have selected Tuesday </p>
            <p *ngSwitchCase="3">You have selected Wednesday </p>
            <p *ngSwitchDefault> Sorry Invalid day ..!</p>

          </div>

          <!-- NOTE: IF ELSE --> <!-- Angular 5 has introduced else with *ngIf  -->
          <ng-container *ngIf="isLoggedIn; then loggedIn; else loggedOut;"></ng-container>

          <ng-template #loggedIn>
           <!-- <div> Welcome back Friend ..!</div> -->
            <app-register></app-register>
          </ng-template>
          <ng-template #loggedOut>
            <div> Please Friend Login ..!</div>
          </ng-template>
  `,
  // templateUrl: './structural-directive.component.html',
  styleUrls: ['./structural-directive.component.css']
})

// *ngIf, *ngFor, *ngSwitchCase, these built-in directives are known as STRUCTURAL DIRECTIVES
// THESE DIRECTIVES DEALS WITH MANIPULATING DOM ELEMENTS. 
// It uses * sign before the directive name
export class StructuralDirectiveComponent implements OnInit {
  isLoggedIn = true;
  day=1;
  title = "DEMO ON STRUCTURAL DIRECTIVES - *ngIf, *ngFor, *ngSwitchCase [ngSwitch]";
  constructor() { }

  ngOnInit() {
  }

}
