import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';


@Component({
  selector: 'app-search-game',
  templateUrl: './search-game.component.html',
  styleUrls: ['./search-game.component.css']
})
export class SearchGameComponent implements OnInit {

//  @Input decorator sends data from  parent component to child component
  @Input() searchText: string="";

  //  @Output decorator sends data from  child component to parent component
  // Note: using object of EventEmitter class 

  @Output() 
  keyupevent = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }

  searchByGameName(name: string){
    this.keyupevent.emit(name);
  }

}
