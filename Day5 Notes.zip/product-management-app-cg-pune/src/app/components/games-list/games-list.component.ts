import { Component, OnInit } from '@angular/core';
import { Game } from '../../models/game.model';
import { GameService } from '../../services/game.service';

@Component({
  selector: 'app-games-list',
  templateUrl: './games-list.component.html',
  styleUrls: ['./games-list.component.css']
})
export class GamesListComponent implements OnInit {

  games: Game[];
  currentBalance: number;
  constructor(private gameService: GameService) { }

  ngOnInit() {
    this.currentBalance = this.gameService.getBalance();

    this.getGames();
    
  }

  getGames(){
    this.gameService.getGamesList().subscribe(data => {
      this.games = data;
    },
      err => {
        console.log(err.stack);
      })
  }
  name:string = "";
  // searchByGameName()
  searchByGameName(value: string) {

    if (value != '') {
      this.name = value;
      console.log(value);
      this.games = this.games.filter(g => g.gameName.toLowerCase()
        .startsWith(value.toLowerCase()));
    }
    else {
      this.name="";
      this.gameService.getGamesList().subscribe(data => {
        this.games = data;
      }, err => {
        this.games = [];
        console.log(err.stack);
      })
    }
  }

}
