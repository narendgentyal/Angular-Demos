import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent   {

  myNumber: number = 100;

  constructor() { 
    console.log(`constructor - My number is ${this.myNumber}`);
  }
  
  // first Lifecycle hook
  ngOnChanges(){
    console.log(`ngOnChanges - My number is ${this.myNumber}`);
  }
  // second Lifecycle hook
  ngOnInit() {
    console.log(`ngOnInit - My number is ${this.myNumber}`);
  }
  // third Lifecycle hook
  ngDoCheck(){
    console.log("ngDoCheck");
  }
  // Fourth Lifecycle hook
  ngAfterContentInit(){
    console.log("ngAfterContentInit");
  }
   // Fifth Lifecycle hook
   ngAfterContentChecked(){
    console.log("ngAfterContentChecked");
  }
  // Sixth Lifecycle hook
  ngAfterViewInit(){
    console.log("ngAfterViewInit");
  }
   // Seventh Lifecycle hook
   ngAfterViewChecked(){
    console.log("ngAfterViewChecked");
  }
  // Eigth Lifecycle hook
  ngOnDestroy(){
    console.log("ngOnDestroy");
  }
  // application logic
  increment(){
    this.myNumber+=10;
  }
  decrement(){
    this.myNumber-=10;
  }
}
