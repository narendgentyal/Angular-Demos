import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attribute-directive',
  template:`
  <button style="color:blue" [ngStyle]="applyStyles()">Click Me </button>
  `,
 // templateUrl: './attribute-directive.component.html',
  styleUrls: ['./attribute-directive.component.css']
})
// ATTRIBUTE DIRECTIVE -> routerLink, formGroup, ngStyle, ngClass, etc
// These attribute directives deals with changing look and behaviour of the dom element
export class AttributeDirectiveComponent implements OnInit {

  isBold: boolean =true;
  isItalic: boolean = true;
  fontSize: number = 30;

  applyStyles(){
    let styles = {
      'font-weight':this.isBold ? 'bold' : 'normal',
      'font-style':this.isItalic ? 'italic' : 'normal' ,
      'font-size.px': this.fontSize 
    };
    return styles;
  }
  constructor() { }

  ngOnInit() {
  }

}
