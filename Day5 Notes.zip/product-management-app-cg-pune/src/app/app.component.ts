import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  // template: `<h1>Welcome to My Product Management App </h1>
  //             <hr/>
  //             <h2>Thank you </h2>`
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'product-management-app';
}
