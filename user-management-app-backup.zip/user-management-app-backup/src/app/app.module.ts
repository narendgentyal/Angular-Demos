import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// To Handle Reactive Forms
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { ListUserComponent } from './components/list-user/list-user.component';
import { SqrtPipe } from './pipes/sqrt.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    AddUserComponent,
    EditUserComponent,
    ListUserComponent,
    SqrtPipe    // registering all userdefined
                    //   components, directives,
                    // pipes
                        
  ],
  imports: [
    BrowserModule,  // Registering Predefined 
                      // and User defined
    AppRoutingModule,  // modules for e.g:
    ReactiveFormsModule                // ReactiveFormsModule, etc
  ],
  providers: [],    // Registering userdefined 
                    // services
  bootstrap: [AppComponent]   // Specifies startup 
                              //  component
})
export class AppModule { }
